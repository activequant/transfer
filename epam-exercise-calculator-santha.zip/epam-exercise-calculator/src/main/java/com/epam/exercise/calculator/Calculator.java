package com.epam.exercise.calculator;

import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class Calculator {

    private static final String LINE_SEPARATOR = "\n";
    private static final String DEFAULT_DELIMITER = ",";
    private static final String DELIMITER_LINE_PREFIX = "//";
    private static final String ILLEGAL_ARGUMENT_EXCEPTION_MSG = "Negatives not allowed: %s";
    private static final String NEGATIVE_PREFIX = "-";
    private static final int MAX_NUMBER = 1000;
    private static final String DELIMITER_SEPARATOR = "|";

    public int add(String numbers) {
        String delimiter = DEFAULT_DELIMITER;
        if (numbers.startsWith(DELIMITER_LINE_PREFIX)) {
            delimiter = evaluateCustomDelimiter(numbers);
            numbers = getInputNumberSequenceWithoutDelimiterDefinitionLine(numbers);
        }

        List<Integer> numberList = getNumberList(numbers, delimiter);

        checkNegativeValues(numberList);

        return numberList.stream()
                .filter(value -> value <= MAX_NUMBER)
                .mapToInt(Integer::intValue).sum();
    }

    private String evaluateCustomDelimiter(String numbers) {
        int delimiterPrefixLength = DELIMITER_LINE_PREFIX.length();
        int delimiterCharSequenceEndIndex = numbers.indexOf(LINE_SEPARATOR);
        String patternString = numbers.substring(delimiterPrefixLength, delimiterCharSequenceEndIndex);
        return Arrays.stream(patternString.split(DELIMITER_SEPARATOR))
                .map(Pattern::quote).collect(Collectors.joining(DELIMITER_SEPARATOR));
    }

    private String getInputNumberSequenceWithoutDelimiterDefinitionLine(String numbers) {
        int firstLineSeparatorIndex = numbers.indexOf(LINE_SEPARATOR);
        int lineSeparatorLength = LINE_SEPARATOR.length();
        return numbers.substring(firstLineSeparatorIndex + lineSeparatorLength);
    }


    private void checkNegativeValues(List<Integer> numberList) {
        List<Integer> negatives = numberList.stream()
                .filter(value -> value < 0).distinct()
                .collect(Collectors.toList());
        if (negatives.size() != 0) {
            String negativesString = negatives.stream()
                    .map(value -> Integer.toString(value))
                    .collect(Collectors.joining( DEFAULT_DELIMITER));
            String exceptionMessage = String.format(ILLEGAL_ARGUMENT_EXCEPTION_MSG, negativesString);
            throw new IllegalArgumentException(exceptionMessage);
        }
    }

    private List<Integer> getNumberList(String numbers, String delimiter) {
        return Arrays.stream(numbers.split(delimiter))
                .flatMap(s -> Arrays.stream(s.split(LINE_SEPARATOR)))
                .filter(s -> !s.isEmpty())
                .filter(this::allNumbers)
                .map(Integer::parseInt).collect(Collectors.toList());
    }

    private boolean allNumbers(String s) {
        if (s.startsWith(NEGATIVE_PREFIX)){
            return s.substring(NEGATIVE_PREFIX.length()).chars().allMatch(Character::isDigit);
        }
        return s.chars().allMatch(Character::isDigit);
    }

}
