package com.epam.exercise.calculator;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class CalculatorTest {
    
    private Calculator calculator;
    
    @Before
    public void setUp() {
        calculator = new Calculator();
    }

    @Test
    public void shouldReturnZeroForEmptyInput() throws Exception {
        int result = calculator.add("");

        assertEquals(0, result);
    }

    @Test
    public void shouldReturnCorrectResultOnOneInput() throws Exception {
        int result = calculator.add("5");

        assertEquals(5, result);
    }

    @Test
    public void shouldReturnSumOnTwoInputs() throws Exception {
        int result = calculator.add("5,3");

        assertEquals(8, result);
    }

    @Test
    public void shouldSumUnknownAmountOfParamsCorrectly() throws Exception {
        int result = calculator.add("1,2,3,4,5,6,7,8,9,10,11");

        assertEquals(66, result);
    }

    @Test
    public void shouldHandleNewLinesCorrectly() throws Exception {
        int result = calculator.add("1,2,3,4,5,6\n7,8,9,10,11");

        assertEquals(66, result);
    }

    @Test
    public void shouldHandleCustomDelimiterCorrectly() throws Exception {
        int result = calculator.add("//;\n1;2;3;4;5;6\n7;8;9;10;11");

        assertEquals(66, result);
    }

    @Test(expected = IllegalArgumentException.class)
    public void shouldThrowExceptionWithCorrectType() throws Exception {
        calculator.add("1,2,-2");
    }

    @Test
    public void shouldThrowExceptionWithCorrectMessage() throws Exception {
        try {
            calculator.add("1,2,3,4,5,-6,7,8,-9,10,-11,-11");
        } catch (IllegalArgumentException e) {
            assertEquals("Negatives not allowed: -6,-9,-11", e.getMessage());
        }
    }

    @Test
    public void shouldIgnoreBigNumbers() throws Exception {
        int sum = calculator.add("1000,233,1001");

        assertEquals(1233, sum);
    }

    @Test
    public void shouldHandleCustomLengthDelimiter() throws Exception {
        int sum = calculator.add("//***\n1***2***3");

        assertEquals(6, sum);
    }

    @Test
    public void shouldHandleMultipleDelimiters() throws Exception {
        int sum = calculator.add("//*|%\n1*2%3");

        assertEquals(6, sum);
    }

    @Test
    public void shouldHandleMultipleCustomLengthDelimiters() throws Exception {
        int sum = calculator.add("//***|%\n1***2%3");

        assertEquals(6, sum);
    }
}
