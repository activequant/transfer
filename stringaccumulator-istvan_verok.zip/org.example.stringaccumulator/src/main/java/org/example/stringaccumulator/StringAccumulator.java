package org.example.stringaccumulator;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.apache.commons.lang3.tuple.Pair;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.IntConsumer;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author Istvan Verok
 */
public class StringAccumulator {

    private static final String LINE_SEPARATOR = "\n";
    private static final String DEFAULT_NUM_DELIMITER = ",";
    private static final String START_NUM_DELIMITER = "//";
    private static final String NUM_DELIMITER_SEPARATOR = "\\|";
    private static final String REGEX_OR = "|";

    /**
     * @param delims Input delimiters.
     * @return Each delimiter quoted as a regex literal, then all of them ORed together.
     */
    private String quoteNumDelimiters(final String delims) {
        return Stream.of(delims.split(NUM_DELIMITER_SEPARATOR))
                .map(Pattern::quote)
                .collect(Collectors.joining(REGEX_OR));
    }

    /**
     * If first line specifies delimiters (starts with "//"), return the delimiters
     * plus the rest of the lines,
     * otherwise return the default delimiters and all the lines intact.
     *
     * @param lines Lines whose first line may contain delimiters.
     * @return Delimiters and lines.
     */
    private Pair<String, Stream<String>> peekNumDelimiters(final String[] lines) {
        Pair<String, Stream<String>> defPair = ImmutablePair.of(DEFAULT_NUM_DELIMITER, Stream.of(lines));

        if (0 == lines.length) {
            return defPair;
        }
        String line = lines[0];
        if (!(line.startsWith(START_NUM_DELIMITER))) {
            return defPair;
        }
        String numDelims = quoteNumDelimiters(line.substring(START_NUM_DELIMITER.length()));
        if (numDelims.isEmpty()) {
            return defPair;
        }

        return ImmutablePair.of(numDelims, Arrays.stream(lines, 1, lines.length));
    }

    /**
     * Parses a single number into an int,
     * if parse fails returns 0 instead of exception.
     *
     * @param s String to parse.
     * @return Parsed int or 0.
     */
    private int numToInt(final String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException nfe) {
            return 0;
        }
    }

    /**
     * Returns a consumer that collects negative integers in the given list.
     *
     * @param negativeInts The list to collect negative ints.
     * @return A consumer that collects negative integers in the given list.
     */
    private IntConsumer collectNegativeInts(final List<Integer> negativeInts) {
        return value -> {
            if (value < 0) {
                negativeInts.add(Integer.valueOf(value));
            }
        };
    }

    /**
     * 1. Create a simple string calculator with a method int add(String numbers)
     * a. The method can take 0, 1 or 2 numbers and will return their sum (for an empty string it will return 0)
     * for example "" or "1" or "1,2"
     * b. Start with the simplest test case of an empty string and move to 1 and 2 numbers.
     * 2. Allow the add method to handle an unknown amount of numbers.
     * 3. Allow the add method to handle new lines between numbers (instead of commas).
     * a. The following input is ok: "1\n2,3" (will equal 6).
     * b. The following input is NOT ok: "1,\n" (don’t need to prove it - just clarifying).
     * 4. Support different delimiters.
     * a. To change a delimiter, the beginning of the string will contain a separate line that looks like this:
     * "//<delimiter>\n<numbers...>", for example "//;\n1;2" should return 3 where the delimiter is ';'.
     * b. The first line is optional, all existing scenarios should still be supported.
     * 5. Calling add with a negative number will throw an exception with the message "negatives not allowed" - and
     * the negative that was passed.
     * a. If there are multiple negatives, show all of them in the exception message.
     * 6. Numbers bigger than 1000 should be ignored, so adding 2 + 1001 = 2.
     * 7. Delimiters can be of any length, for example: "//***\n1***2***3" should return 6.
     * 8. Allow multiple delimiters like this: "//delim1|delim2\n" (with a "|" separating delimiters),
     * for example "//*|%\n1*2%3" should return 6.
     * 9. Make sure you can also handle multiple delimiters with length longer than one character.
     *
     * @param numbers Numbers to add.
     * @return Sum of numbers.
     * @throws IllegalArgumentException When at least one negative number was passed.
     */
    public int add(final String numbers) throws IllegalArgumentException {
        String[] lines0 = numbers.split(LINE_SEPARATOR);

        Pair<String, Stream<String>> numDelimsAndLines = peekNumDelimiters(lines0);
        String numDelims = numDelimsAndLines.getLeft();
        Stream<String> lines = numDelimsAndLines.getRight();

        List<Integer> negativeInts = new ArrayList<>();

        int sum = lines.flatMap(line -> Stream.of(line.split(numDelims)))
                .mapToInt(this::numToInt)
                .peek(collectNegativeInts(negativeInts))
                .filter(i -> i <= 1000)
                .sum();

        if (!(negativeInts.isEmpty())) {
            throw new IllegalArgumentException(MessageFormat.format("negatives not allowed: {0}", negativeInts));
        }

        return sum;
    }

}
