package org.example.stringaccumulator;

import org.junit.Assert;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

/**
 * @author Istvan Verok
 */
public class StringAccumulatorTest {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private void assertStringAccumulatorResult(final String numbers, final int expectedValue)
            throws IllegalArgumentException {
        int actualValue = new StringAccumulator().add(numbers);
        Assert.assertEquals(numbers, expectedValue, actualValue);
    }

    @Test
    public void empty_0() {
        assertStringAccumulatorResult("", 0);
    }

    @Test
    public void one_1() {
        assertStringAccumulatorResult("1", 1);
    }

    @Test
    public void oneTwo_3() {
        assertStringAccumulatorResult("1,2", 3);
    }

    @Test
    public void manyNums_55() {
        assertStringAccumulatorResult("1,2,3,4,5,6,7,8,9,10", 55);
    }

    @Test
    public void multiLine1_6() {
        assertStringAccumulatorResult("1\n2,3", 6);
    }

    @Test
    public void multiLineWithEmpty_1() {
        assertStringAccumulatorResult("1,\n", 1);
    }

    @Test
    public void semicolon_empty_0() {
        assertStringAccumulatorResult("//;", 0);
    }

    @Test
    public void semicolon_emptynewline_0() {
        assertStringAccumulatorResult("//;\n", 0);
    }

    @Test
    public void semicolon_one_1() {
        assertStringAccumulatorResult("//;\n1", 1);
    }

    @Test
    public void semicolon_oneTwo_3() {
        assertStringAccumulatorResult("//;\n1;2", 3);
    }

    @Test
    public void semicolon_manyNums_55() {
        assertStringAccumulatorResult("//;\n1;2;3;4;5;6;7;8;9;10", 55);
    }

    @Test
    public void semicolon_multiLine1_6() {
        assertStringAccumulatorResult("//;\n1\n2;3", 6);
    }

    @Test
    public void semicolon_multiLineWithEmpty_1() {
        assertStringAccumulatorResult("//;\n1;\n", 1);
    }

    @Test
    public void minusOne_exception() {
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage("negatives not allowed: [-1]");
        assertStringAccumulatorResult("-1", 1);
    }

    @Test
    public void minusOneMinusTwo_exception() {
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage("negatives not allowed: [-1, -2]");
        assertStringAccumulatorResult("-1,-2", 1);
    }

    @Test
    public void semicolon_minusOneMinusTwo_exception() {
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage("negatives not allowed: [-1, -2]");
        assertStringAccumulatorResult("//;\n-1;-2", 1);
    }

    @Test
    public void twoNinehundredNinetyNine_2() {
        assertStringAccumulatorResult("2,999", 1001);
    }

    @Test
    public void twoThousand_2() {
        assertStringAccumulatorResult("2,1000", 1002);
    }

    @Test
    public void twoThousandOne_2() {
        assertStringAccumulatorResult("2,1001", 2);
    }

    @Test
    public void twoThousandTwo_2() {
        assertStringAccumulatorResult("2,1002", 2);
    }

    @Test
    public void starStarStar_oneTwoThree_6() {
        assertStringAccumulatorResult("//***\n1***2***3", 6);
    }

    @Test
    public void starOrPercent_oneTwoThree_6() {
        assertStringAccumulatorResult("//*|%\n1*2%3", 6);
    }

    @Test
    public void starStarOrPercentPercent_oneTwoThree_6() {
        assertStringAccumulatorResult("//**|%%\n1**2%%3", 6);
    }

    @Test
    public void hyphen_oneTwoThree_6() {
        assertStringAccumulatorResult("//-\n1-2-3", 6);
    }

    @Test
    public void hyphenHyphenHyphen_oneTwoThree_6() {
        assertStringAccumulatorResult("//---\n1---2---3", 6);
    }

    @Test
    public void hyphenHyphenHyphen_oneMinusTwoThree_exception() {
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage("negatives not allowed: [-2]");
        assertStringAccumulatorResult("//---\n1----2---3", 6);
    }

    @Test
    public void four_oneTwoThree_6() {
        assertStringAccumulatorResult("//4\n14243", 6);
    }

}
