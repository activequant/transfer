package personal.andreea.interviews.epam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import personal.andreea.interviews.epam.validation.InvalidNumberException;

/**
 * Unit test for class NumbersExtracter.
 */
public class NumbersExtracterTest extends TestCase {
	/**
	 * Create the test case
	 *
	 * @param testName
	 *            name of the test case
	 */
	public NumbersExtracterTest(String testName) {
		super(testName);
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite() {
		return new TestSuite(NumbersExtracterTest.class);
	}

	public void test1() throws InvalidNumberException {
		List<String> delimiters = new ArrayList<>();
		delimiters.add("\n");
		delimiters.add(",");
		
		NumbersExtracter extracter = new NumbersExtracter("1\n2,3", delimiters);
		
		assertEquals(Arrays.asList(new Integer[]{1,2,3}), extracter.extractNumbers());
	}

	public void testEmptyString() throws InvalidNumberException {
		List<String> delimiters = new ArrayList<>();
		delimiters.add("\n");
		NumbersExtracter extracter = new NumbersExtracter("", delimiters);
		assertEquals(new ArrayList<>(0), extracter.extractNumbers());
	}
	
	public void testMultipleDelimiters() throws InvalidNumberException {
		List<String> delimiters = new ArrayList<>();
		delimiters.add("\n");
		delimiters.add(",");
		delimiters.add("**");
		
		NumbersExtracter extracter = new NumbersExtracter("1\n2,3**4", delimiters);
		
		assertEquals(Arrays.asList(new Integer[]{1,2,3,4}), extracter.extractNumbers());
	}
	//
	// public void testChangeDelimiter() throws InvalidNumberException {
	// assertEquals( 3, App.add("//;1;2") );
	// }
	//
	// public void testNegative() {
	// try {
	// App.add("2,-1");
	// throw new AssertionError();
	// } catch (InvalidNumberException e) {
	//
	// }
	// }

}
