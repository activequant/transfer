package personal.andreea.interviews.epam;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import personal.andreea.interviews.epam.validation.InvalidNumberException;

/**
 * Unit test for class NumbersAdder.
 */
public class NumbersAdderTest extends TestCase {
	/**
	 * Create the test case
	 *
	 * @param testName
	 *            name of the test case
	 */
	public NumbersAdderTest(String testName) {
		super(testName);
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite() {
		return new TestSuite(NumbersAdderTest.class);
	}

	public void testSimpleinput() throws InvalidNumberException {
		assertEquals(6, new NumbersAdder("1\n2,3").add());
	}

	public void testEmptyString() throws InvalidNumberException {
		assertEquals(0, new NumbersAdder("").add());
	}
	
	 public void testChangeDelimiter() throws InvalidNumberException {
	 assertEquals(3, new NumbersAdder("//;\n1;2").add() );
	 }
	
	public void testMultipleDelimiters() throws InvalidNumberException {
		assertEquals(6, new NumbersAdder("//***\n1***2***3").add());
	}
	
	public void testLongDelimiters() throws InvalidNumberException {
		assertEquals(6, new NumbersAdder("//*|%\n1*2%3").add());
	}
	public void testIgnoreBiggerThan1000() throws InvalidNumberException {
		assertEquals(5, new NumbersAdder("//*|%\n1001*2%3").add());
	}
	 public void testNegative() {
	 try {
	 new NumbersAdder("2,-1").add();
	 throw new AssertionError("should throw InvalidNumberException");
	 } catch (InvalidNumberException e) {
		 assertEquals("negatives not allowed", e.getMessage());
	 }
	 }

}
