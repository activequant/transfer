package personal.andreea.interviews.epam.validation;

public class ValidationException extends Exception {

	public ValidationException(String message) {
		super(message);
	}

}
