package personal.andreea.interviews.epam.validation;

public enum NumberValidator implements Validator {
	INSTANCE;

	public boolean validate(int number) throws InvalidNumberException {
		if (number < 0) {
			throw new InvalidNumberException("negatives not allowed");
		}
		if (number > 1000) {
			return false;
		}
		return true;
	}

}
