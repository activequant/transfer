package personal.andreea.interviews.epam;

import java.util.List;

public class ParsedInput {

	private List<String> delimiters;
	private String numbersInput;

	public ParsedInput(List<String> delimiters, String numbersInput) {
		this.delimiters = delimiters;
		this.numbersInput = numbersInput;
	}

	public List<String> getDelimiters() {
		return delimiters;
	}

	public String getNumbersInput() {
		return numbersInput;
	}
}
