package personal.andreea.interviews.epam.validation;

public interface Validator {
	boolean validate(int number) throws InvalidNumberException;
}
