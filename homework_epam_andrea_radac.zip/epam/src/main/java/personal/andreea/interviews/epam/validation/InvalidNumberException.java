package personal.andreea.interviews.epam.validation;

public class InvalidNumberException extends ValidationException {

	public InvalidNumberException(String message) {
		super(message);
	}

}
