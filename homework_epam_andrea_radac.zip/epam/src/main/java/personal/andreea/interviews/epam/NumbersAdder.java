package personal.andreea.interviews.epam;

import java.util.List;

import personal.andreea.interviews.epam.validation.InvalidNumberException;

/**
 * This class will take an input parse it and add the numbers.
 * Maybe just a static method would be sufficient.
 * TODO implement some design pattern here, maybe Command/Pipeline, but no over-engineering needed for now
 * 
 * @author Andreea
 *
 */
public class NumbersAdder {

	private String input;

	public NumbersAdder(String input) {
		this.input = input;
	}

	/**
	 * Adds the numbers found in the input string
	 * @return
	 * @throws InvalidNumberException
	 */
	public int add() throws InvalidNumberException {
		InputParser inputParser = new InputParser(input);
		ParsedInput parsedInput = inputParser.parseString();
		NumbersExtracter extracter = new NumbersExtracter(parsedInput.getNumbersInput(), parsedInput.getDelimiters());
		List<Integer> numbers = extracter.extractNumbers();

		return numbers.stream().reduce(0, Integer::sum);
	}
}
