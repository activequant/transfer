package personal.andreea.interviews.epam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

/**
 * 
 * @author Andreea
 *
 */
public class InputParser {
	private static final String DELIMITERS_SEPARATOR = Pattern.quote("|");
	private static final String DEFAULT_DELIMITER = "\n";
	private static final String DEFAULT_DELIMITER2 = ",";
	private static final String PREFIX_DELIMITERS = "//";
	private String input;

	public InputParser(String input) {
		this.input = input;
	}

	public ParsedInput parseString() {
		final List<String> delimiters = new ArrayList<>();
		delimiters.add(DEFAULT_DELIMITER);
		final String numbersInput;
		if (input.startsWith(PREFIX_DELIMITERS)) {
			String delimitersString = input.substring(2, input.indexOf(DEFAULT_DELIMITER));
			delimiters.addAll(Arrays.asList(delimitersString.split(DELIMITERS_SEPARATOR)));
			numbersInput = input.substring(input.indexOf(DEFAULT_DELIMITER) + 1);
		} else {
			numbersInput = input;
			delimiters.add(DEFAULT_DELIMITER2);
		}
		return new ParsedInput(delimiters, numbersInput);
	}
}
