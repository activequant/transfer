package personal.andreea.interviews.epam;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Pattern;

import personal.andreea.interviews.epam.validation.InvalidNumberException;
import personal.andreea.interviews.epam.validation.NumberValidator;
import personal.andreea.interviews.epam.validation.Validator;

/**
 * This class is used to extract the numbers from the input string using the specified delimiters.
 * 
 * @author Andreea
 *
 */
public class NumbersExtracter {
	private final String input;
	private final List<String> delimiters;
	private final Validator validator;

	public NumbersExtracter(String input, List<String> delimiters) {
		this.input = input;
		this.delimiters = delimiters;
		this.validator = NumberValidator.INSTANCE;
	}

	/**
	 * Extracts the list of numbers from the input using the delimiters
	 * 
	 * @return
	 * @throws InvalidNumberException
	 */
	public List<Integer> extractNumbers() throws InvalidNumberException {
		ArrayList<Integer> numbersList = new ArrayList<>();

		numbersList.addAll(findNumbers(input, delimiters));
		return numbersList;
	}

	private List<Integer> findNumbers(String numbers, List<String> delimiters) throws InvalidNumberException {
		List<Integer> numbersList = new ArrayList<>(2);
		Iterator<String> iterator = delimiters.iterator();
		String firstDelimiter = iterator.next();
		if (delimiters.size() > 1) {
			while (iterator.hasNext()) {
				String delimiter = iterator.next();
				numbers = numbers.replaceAll(Pattern.quote(delimiter), firstDelimiter);
			}
		}
		numbersList.addAll(findNumbers(numbers, firstDelimiter));
		return numbersList;
	}

	private List<Integer> findNumbers(String numbers, String delimiter) throws InvalidNumberException {
		if (numbers.isEmpty()) {
			return new ArrayList<>(0);
		}
		String[] stringList = numbers.split(Pattern.quote(delimiter));
		List<Integer> numbersList = new ArrayList<>(stringList.length);

		for (int i = 0; i < stringList.length; i++) {
			String numberString = stringList[i];
			try {
				addValidNumber(numbersList, numberString);
			} catch (NumberFormatException e) {
				// do not break, just move on
				// TODO log exception
			}
		}
		return numbersList;
	}

	private void addValidNumber(List<Integer> numbersList, String numberString) throws InvalidNumberException {
		// TODO re-think this code as the method already does 2 things: validate and add
		int number = Integer.parseInt(numberString);
		if (validator.validate(number)) {
			numbersList.add(number);
		}
	}
}
