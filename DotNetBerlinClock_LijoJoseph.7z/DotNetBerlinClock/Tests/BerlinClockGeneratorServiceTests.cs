﻿using NUnit.Framework;

namespace BerlinClock.Tests
{
    public class BerlinClockGeneratorServiceTests
    {   
        [TestCase("00:00:00", "Y\r\nOOOO\r\nOOOO\r\nOOOOOOOOOOO\r\nOOOO")]
        [TestCase("13:17:01", "O\r\nRROO\r\nRRRO\r\nYYROOOOOOOO\r\nYYOO")]
        [TestCase("23:59:59", "O\r\nRRRR\r\nRRRO\r\nYYRYYRYYRYY\r\nYYYY")]
        [TestCase("24:00:00", "Y\r\nRRRR\r\nRRRR\r\nOOOOOOOOOOO\r\nOOOO")]
        public void GivenTime_WhenTimeIsValid_ThenClockIsCorrect(string time, string expectedResult)
        {
            var service = new Services.BerlinClockGeneratorService();
            var result = service.GetClockRepresentation(time);

            Assert.AreEqual(expectedResult, result);
        }
    }
}
