﻿namespace BerlinClock
{
    public class TimeConverter : ITimeConverter
    {
        public string convertTime(string aTime)
        {
            var service = new Services.BerlinClockGeneratorService();
            var result = service.GetClockRepresentation(aTime);
            return result;
        }
    }
}
