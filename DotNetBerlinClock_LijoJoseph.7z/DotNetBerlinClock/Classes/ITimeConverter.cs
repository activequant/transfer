﻿using System;

namespace BerlinClock
{
    public interface ITimeConverter
    {
        String convertTime(String aTime);
    }
}
