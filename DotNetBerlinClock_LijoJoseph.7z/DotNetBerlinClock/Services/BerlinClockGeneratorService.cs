﻿using System;
using System.Linq;

namespace BerlinClock.Services
{
    public class BerlinClockGeneratorService
    {
        private const string ColorYellow = "Y";
        private const string ColorRed = "R";
        private const string ColorNotActive = "O";
        private const string ColorDefaultMinutes11Bulb = "YYRYYRYYRYY";

        private int _clockHours;
        private int _clockMinutes;
        private int _clockSeconds;

        public string BulbStateSeconds { get; private set; } = ColorYellow;
        public string BulbStateHours5 { get; private set; } = string.Concat(Enumerable.Repeat(ColorNotActive, 4));
        public string BulbStateHours1 { get; private set; } = string.Concat(Enumerable.Repeat(ColorNotActive, 4));
        public string BulbStateMinutes11 { get; private set; } = string.Concat(Enumerable.Repeat(ColorNotActive, 11));
        public string BulbStateMinutes1 { get; private set; } = string.Concat(Enumerable.Repeat(ColorNotActive, 4));

        public string GetClockRepresentation(string aTime)
        {
            string clockResult = string.Empty;
            bool bContinue = false;

            // Parse the date
            bContinue = ParseDate(aTime);

            if (bContinue)
            {
                // Seconds - First Row
                BuildSecondsBulb();

                // Hours - Second Row
                BuildHours5Bulb();

                // Hours - Third Row
                BuildHours1Bulb();

                // Minutes - Fourth Row
                BuildMinutes11Bulb();

                // Minutes - Fifth Row
                BuildMinutes1Bulb();

                clockResult = $"{BulbStateSeconds}{Environment.NewLine}{BulbStateHours5}{Environment.NewLine}{BulbStateHours1}{Environment.NewLine}{BulbStateMinutes11}{Environment.NewLine}{BulbStateMinutes1}";
            }


            return clockResult;
        }

        private void BuildSecondsBulb()
        {
            BulbStateSeconds = _clockSeconds % 2 == 0 ? ColorYellow : ColorNotActive;
        }

        private void BuildHours5Bulb()
        {
            var remainder = _clockHours / 5;
            BulbStateHours5 = BuildHoursBulb(remainder);
        }

        private void BuildHours1Bulb()
        {
            var remainder = _clockHours % 5;
            BulbStateHours1 = BuildHoursBulb(remainder);
        }

        private string BuildHoursBulb(int remainder)
        {
            var result = string.Empty;
            Enumerable.Range(1, 4).ToList()
                      .ForEach(i =>
                      {
                          if (i <= remainder)
                          {
                              result = $"{result}{ColorRed}";
                          }
                          else
                          {
                              result = $"{result}{ColorNotActive}";
                          }
                      });

            return result;
        }

        private void BuildMinutes11Bulb()
        {
            if (_clockMinutes >= 55)
            {
                BulbStateMinutes11 = ColorDefaultMinutes11Bulb;
            }
            else
            {
                BulbStateMinutes11 = string.Empty;
                var loopCount = -1;
                for (var index = 5; index < 60; index = index + 5)
                {
                    loopCount++;
                    if (_clockMinutes > index)
                    {
                        BulbStateMinutes11 = (loopCount % 3 == 2) ? $"{BulbStateMinutes11}{ColorRed}" : $"{BulbStateMinutes11}{ColorYellow}";
                    }
                    else
                    {
                        BulbStateMinutes11 = $"{BulbStateMinutes11}{ColorNotActive}";
                    }
                }
            }
        }

        private void BuildMinutes1Bulb()
        {
            var remainder = _clockMinutes % 5;
            var result = string.Empty;
            Enumerable.Range(1, 4).ToList()
                      .ForEach(i =>
                      {
                          if (i <= remainder)
                          {
                              result = $"{result}{ColorYellow}";
                          }
                          else
                          {
                              result = $"{result}{ColorNotActive}";
                          }
                      });
            BulbStateMinutes1 = result;
        }

        private bool ParseDate(string aTime)
        {
            var parsedSuccess = false;

            try
            {
                DateTime timeToParse = DateTime.Now;
                if (DateTime.TryParse(aTime, out timeToParse))
                {
                    _clockHours = timeToParse.Hour;
                    _clockMinutes = timeToParse.Minute;
                    _clockSeconds = timeToParse.Second;
                }
                else
                {
                    var timeArray = aTime.Split(':');
                    _clockHours = Convert.ToInt32(timeArray[0]);
                    _clockMinutes = Convert.ToInt32(timeArray[1]);
                    _clockSeconds = Convert.ToInt32(timeArray[2]);
                }

                parsedSuccess = true;
            }
            catch (Exception exp)
            {
                System.Diagnostics.Debug.WriteLine(exp);
            }

            return parsedSuccess;
        }
    }
}
